﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cupcakes.Models
{
    public enum CupcakeType
    {
        Birthday,
        Turquoise,
        Chocolate,
        Strawberry
    }
}
