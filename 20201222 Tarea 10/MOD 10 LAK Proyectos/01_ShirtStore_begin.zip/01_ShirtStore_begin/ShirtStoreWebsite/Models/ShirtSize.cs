﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShirtStoreWebsite.Models
{
    public enum ShirtSize
    {
        XS,
        S,
        M,
        L,
        XL,
        XXL
    }
}
