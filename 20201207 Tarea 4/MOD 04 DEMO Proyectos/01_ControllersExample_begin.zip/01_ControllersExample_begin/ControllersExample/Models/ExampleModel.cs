﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ControllersExample.Models
{
    public class ExampleModel
    {
        public string Sentence { get; set; }
    }
}
