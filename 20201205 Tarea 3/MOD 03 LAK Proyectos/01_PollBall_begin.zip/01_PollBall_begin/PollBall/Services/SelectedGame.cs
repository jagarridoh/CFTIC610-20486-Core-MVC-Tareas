﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PollBall.Services
{
    //public class SelectedGame
    public enum SelectedGame
    {
        Basketball,
        Football,
        Soccer,
        Volleyball,
        Billiard,
        Hockey,
        Golf,
        Tennis
    }
}
