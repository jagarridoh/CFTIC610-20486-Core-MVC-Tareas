﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ErrorHandlingExample.Models
{
    public class DivisionResult
    {
        public int DividedNumber { get; set; }

        public List<int> DividingNumbers { get; set; }
    }
}
