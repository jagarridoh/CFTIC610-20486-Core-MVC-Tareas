﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;

namespace LoggingExample.Models
{
    public class DivisionResult
    {
        public int DividedNumber { get; set; }

        public List<int> DividingNumbers { get; set; }
    }
}
